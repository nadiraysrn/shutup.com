import { SavedLook } from '../types';

const WISHLIST_KEY = 'by_occasions_wishlist';
const MY_STYLE_ITEMS_KEY = 'by_occasions_my_style_items';
const SAVED_LOOKS_KEY = 'by_occasions_saved_looks';

export function getStoredWishlist(): string[] {
  try {
    const raw = localStorage.getItem(WISHLIST_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setStoredWishlist(ids: string[]): void {
  try {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(ids));
  } catch (e) {
    console.warn('Storage unavailable:', e);
  }
}

export function getStoredMyStyleItems(): string[] {
  try {
    const raw = localStorage.getItem(MY_STYLE_ITEMS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setStoredMyStyleItems(ids: string[]): void {
  try {
    localStorage.setItem(MY_STYLE_ITEMS_KEY, JSON.stringify(ids));
  } catch (e) {
    console.warn('Storage unavailable:', e);
  }
}

export function getStoredSavedLooks(): SavedLook[] {
  try {
    const raw = localStorage.getItem(SAVED_LOOKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setStoredSavedLooks(looks: SavedLook[]): void {
  try {
    localStorage.setItem(SAVED_LOOKS_KEY, JSON.stringify(looks));
  } catch (e) {
    console.warn('Storage unavailable:', e);
  }
}
