export type Occasion =
  | 'Party'
  | 'Beach'
  | 'Formal'
  | 'Corporate'
  | 'Casual · Street'
  | 'Casual · Weekend'
  | 'First date';

export type Category =
  | 'hijab'
  | 'top'
  | 'bottom'
  | 'dress'
  | 'set'
  | 'shoes'
  | 'accessories';

export type Budget = 'affordable' | 'mid' | 'high fashion';

export type Store = 'Shopee' | 'Amazon';

export interface Product {
  id: string;
  name: string;
  occasion: Occasion;
  category: Category;
  budget: Budget;
  color: string;
  image: string;
  store: Store;
  buyUrl: string;
  reviewUrl: string;
  reviewEmbedUrl?: string;
  description?: string;
}

export interface SavedLook {
  id: string;
  title: string;
  occasion: Occasion;
  vibe: string;
  budget: Budget;
  itemIds: string[];
  createdAt: string;
  stylingNote?: string;
}
