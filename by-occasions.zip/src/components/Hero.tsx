import React from 'react';
import { Sparkles, Compass } from 'lucide-react';

interface HeroProps {
  onOpenQuiz: () => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenQuiz, onExploreClick }) => {
  return (
    <section className="relative overflow-hidden pt-10 pb-8 sm:pt-14 sm:pb-12 border-b border-[#EBDCF6]/70">
      {/* Subtle lilac gradient orbs */}
      <div
        className="pointer-events-none absolute -top-24 -left-20 w-80 h-80 rounded-full bg-[#EBDCF6]/60 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute top-10 -right-20 w-96 h-96 rounded-full bg-[#F3DEF5]/50 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#F3E7F8] border border-[#E4CEF2] text-[#5C2750] text-xs font-medium uppercase tracking-wider mb-5">
          <Sparkles className="w-3.5 h-3.5 text-[#8C467C]" />
          <span>Curated Modesty Occasions</span>
        </div>

        <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-normal text-[#2D1527] tracking-tight leading-[1.15] mb-5">
          Where are you going?<br />
          <span
            className="brand-heading-span italic font-normal text-[#5C2750]"
            aria-label="We’ll find what to wear."
          >
            We’ll f&#305;nd what to wear.
          </span>
        </h1>

        <p className="max-w-2xl mx-auto text-base sm:text-lg text-[#664060] font-sans font-normal leading-relaxed mb-8">
          Explore curated modest fashion pieces tailored for every special moment,
          workplace vibe, or casual day out. Hand-picked sets, hijabs, and silhouettes
          with verified reviews and direct store links.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
          <button
            onClick={onExploreClick}
            className="inline-flex items-center justify-center space-x-2 px-6 py-3 rounded-full bg-[#2D1527] text-white hover:bg-[#441D3A] active:scale-[0.98] transition-all text-sm font-medium shadow-sm cursor-pointer"
          >
            <Compass className="w-4 h-4 text-[#dec4ef]" />
            <span>Browse Outfits</span>
          </button>

          <button
            onClick={onOpenQuiz}
            className="inline-flex items-center justify-center space-x-2 px-6 py-3 rounded-full bg-white text-[#2D1527] hover:bg-[#F8F2FB] border border-[#DEC4EF] active:scale-[0.98] transition-all text-sm font-medium shadow-xs cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#8C467C]" />
            <span>Take Style Quiz (4 Qs)</span>
          </button>
        </div>
      </div>
    </section>
  );
};
