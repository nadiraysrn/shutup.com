import React from 'react';
import { Sparkles, HeartHandshake, Compass, ShieldCheck } from 'lucide-react';

export const AboutUs: React.FC = () => {
  return (
    <section className="mt-20 py-16 sm:py-20 bg-gradient-to-b from-[#FAF7FC] via-[#F4EBF8] to-[#FAF7FC] border-t border-[#EBDCF6]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Editorial Subtitle */}
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-[#E4CEF2] text-[#5C2750] text-xs font-semibold uppercase tracking-wider mb-4 shadow-2xs">
          <Sparkles className="w-3.5 h-3.5 text-[#8C467C]" />
          <span>Our Modesty Philosophy</span>
        </div>

        <h2 className="font-serif text-3xl sm:text-4xl text-[#2D1527] font-normal mb-5 leading-snug">
          About By Occasions
        </h2>

        <p className="text-base sm:text-lg text-[#63435B] font-sans leading-relaxed max-w-2xl mx-auto mb-10">
          We believe finding the right modest outfit shouldn’t take endless hours of searching.
          By Occasions curates refined modest styling pieces for every chapter of your week —
          from beach getaways and formal galas to workplace meetings and cozy weekend strolls.
          Every piece is chosen with modest coverage, premium drape, and real reviews in mind.
        </p>

        {/* 3 Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
          <div className="p-5 rounded-2xl bg-white/70 border border-[#EBDCF6] shadow-2xs">
            <div className="w-9 h-9 rounded-xl bg-[#F6EDFA] flex items-center justify-center text-[#5C2750] mb-3">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-medium text-[#2D1527] mb-1">
              Curated by Occasion
            </h3>
            <p className="text-xs text-[#7A5370] leading-relaxed">
              Filtered specifically for where you are going so you never have to wonder what fits the vibe.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white/70 border border-[#EBDCF6] shadow-2xs">
            <div className="w-9 h-9 rounded-xl bg-[#F6EDFA] flex items-center justify-center text-[#5C2750] mb-3">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-medium text-[#2D1527] mb-1">
              Thoughtful Modesty
            </h3>
            <p className="text-xs text-[#7A5370] leading-relaxed">
              Silhouettes designed with proper lengths, opacity, and layering harmony for confident wear.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white/70 border border-[#EBDCF6] shadow-2xs">
            <div className="w-9 h-9 rounded-xl bg-[#F6EDFA] flex items-center justify-center text-[#5C2750] mb-3">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-base font-medium text-[#2D1527] mb-1">
              Verified Reviews & Links
            </h3>
            <p className="text-xs text-[#7A5370] leading-relaxed">
              Real try-on video reviews and direct affiliate links to reputable sellers on Shopee and Amazon.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
