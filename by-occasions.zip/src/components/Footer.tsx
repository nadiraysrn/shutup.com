import React from 'react';
import { Heart, Sparkles } from 'lucide-react';

interface FooterProps {
  onScrollToTop: () => void;
  onOpenQuiz: () => void;
  onOpenWishlist: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onScrollToTop,
  onOpenQuiz,
  onOpenWishlist,
}) => {
  return (
    <footer className="bg-white border-t border-[#EBDCF6] pt-12 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-[#F2E5F8]">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <button
              onClick={onScrollToTop}
              className="text-left font-serif text-2xl font-medium text-[#2D1527] hover:text-[#5C2750] transition-colors"
            >
              By Occasions
            </button>
            <p className="text-sm text-[#7B4C72] max-w-sm leading-relaxed">
              Where are you going? We’ll find what to wear. Curated modest fashion
              and styling directory for everyday moments, celebrations, and professional poise.
            </p>
            <div className="pt-2 text-xs text-[#8C6D85]">
              Built with love for effortless modest elegance.
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider font-semibold text-[#5C2750]">
              Explore
            </h4>
            <ul className="space-y-2 text-xs text-[#63435B]">
              <li>
                <button
                  onClick={onScrollToTop}
                  className="hover:text-[#2D1527] transition-colors cursor-pointer"
                >
                  Shop Occasions Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenQuiz}
                  className="hover:text-[#2D1527] transition-colors inline-flex items-center space-x-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-[#8C467C]" />
                  <span>Build Your Style Quiz</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenWishlist}
                  className="hover:text-[#2D1527] transition-colors inline-flex items-center space-x-1 cursor-pointer"
                >
                  <Heart className="w-3 h-3 text-[#9A3978]" />
                  <span>My Saved Wishlist</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Occasions Quick List */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider font-semibold text-[#5C2750]">
              Occasions
            </h4>
            <div className="flex flex-wrap gap-1.5 text-[11px] text-[#63435B]">
              {['Party', 'Beach', 'Formal', 'Corporate', 'Casual · Street', 'Casual · Weekend', 'First date'].map(
                (occ) => (
                  <span
                    key={occ}
                    className="px-2 py-0.5 rounded-md bg-[#FAF7FC] border border-[#EBDCF6]"
                  >
                    {occ}
                  </span>
                )
              )}
            </div>
          </div>
        </div>

        {/* Affiliate Disclosure Section (Kept prominently in the footer) */}
        <div className="pt-8 space-y-4">
          <div className="bg-[#FAF7FC] border border-[#EBDCF6] rounded-2xl p-4 sm:p-5">
            <h5 className="text-xs font-semibold uppercase tracking-wider text-[#5C2750] mb-1.5">
              Affiliate Disclosure
            </h5>
            <p className="text-xs text-[#7A5370] leading-relaxed">
              By Occasions participates in various affiliate marketing programs, including Shopee Affiliate Program
              and the Amazon Services LLC Associates Program. This means we may earn a small commission on qualifying
              purchases made through our links to retailer sites at no additional cost to you.
              All product selections, style recommendations, and reviews are independently curated with a focus on genuine modest styling value.
              We do not handle payments, orders, or fulfillment on this website.
            </p>
          </div>

          {/* Copyright */}
          <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-[#8C6D85] pt-2">
            <p>© {new Date().getFullYear()} By Occasions. All rights reserved.</p>
            <p className="mt-2 sm:mt-0">Modest fashion inspiration & affiliate guide.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
