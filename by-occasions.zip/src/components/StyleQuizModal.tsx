import React, { useState } from 'react';
import { Occasion, Budget, Product, SavedLook } from '../types';
import { OCCASIONS_LIST } from '../productsData';
import {
  X,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Check,
  BookmarkCheck,
  ShoppingBag,
  ExternalLink,
  RotateCcw,
} from 'lucide-react';

interface StyleQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSaveLook: (look: SavedLook) => void;
  onOpenMyStyle: () => void;
}

interface QuizState {
  vibe: string;
  colors: string;
  occasion: Occasion;
  budget: Budget;
}

const VIBE_OPTIONS = [
  {
    title: 'Minimalist Chic',
    desc: 'Clean lines, fluid draping, understated elegance with zero clutter.',
  },
  {
    title: 'Romantic & Flowy',
    desc: 'Soft accordion pleats, poetic sleeves, sheer layers and tiers.',
  },
  {
    title: 'Modern Tailored',
    desc: 'Sharp blazers, wide-leg trousers, structured modest power wear.',
  },
  {
    title: 'Casual & Relaxed',
    desc: 'Effortless co-ords, breathable duster coats, comfortable fabrics.',
  },
];

const COLOR_OPTIONS = [
  {
    title: 'Pastels & Lilacs',
    desc: 'Dusty mauve, soft lavender, whipped cream, and pearlescent finishes.',
  },
  {
    title: 'Earthy Neutrals',
    desc: 'Oatmeal, sand, rich mocha, camel, and warm ivory tones.',
  },
  {
    title: 'Classic Monochrome',
    desc: 'Deep black, stark cream, charcoal, and crisp contrast.',
  },
  {
    title: 'Rich Jewel Tones',
    desc: 'Deep plum, emerald green, ruby burgundy, and midnight blue.',
  },
];

export const StyleQuizModal: React.FC<StyleQuizModalProps> = ({
  isOpen,
  onClose,
  products,
  onSaveLook,
  onOpenMyStyle,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [answers, setAnswers] = useState<QuizState>({
    vibe: 'Romantic & Flowy',
    colors: 'Pastels & Lilacs',
    occasion: 'Party',
    budget: 'mid',
  });
  const [isSaved, setIsSaved] = useState<boolean>(false);

  if (!isOpen) return null;

  // Compute matched items for this look
  const matchedOccasionProducts = products.filter(
    (p) => p.occasion === answers.occasion
  );

  // If budget matches, prioritize it, otherwise fallback to occasion items
  const matchedBudgetProducts = matchedOccasionProducts.filter(
    (p) => p.budget === answers.budget
  );

  const curatedPieces =
    matchedBudgetProducts.length >= 2
      ? matchedBudgetProducts.slice(0, 4)
      : matchedOccasionProducts.slice(0, 4);

  const styleTitle = `The ${answers.vibe.split(' ')[0]} ${answers.occasion} Edit`;

  const stylingTips = `Pair the ${answers.colors.toLowerCase()} tones with modest layering. A soft drape hijab anchors this ${answers.occasion.toLowerCase()} silhouette with effortless grace.`;

  const handleSaveThisLook = () => {
    const newLook: SavedLook = {
      id: `look-${Date.now()}`,
      title: styleTitle,
      occasion: answers.occasion,
      vibe: answers.vibe,
      budget: answers.budget,
      itemIds: curatedPieces.map((p) => p.id),
      createdAt: new Date().toLocaleDateString(),
      stylingNote: stylingTips,
    };
    onSaveLook(newLook);
    setIsSaved(true);
  };

  const handleResetQuiz = () => {
    setCurrentStep(1);
    setIsSaved(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Quiz Dialog */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-[#DEC4EF] z-10 p-6 sm:p-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-[#63435B] hover:text-[#2D1527] hover:bg-[#F2E5F8] transition-colors focus:outline-none"
          aria-label="Close quiz"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-6">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-[#F4EBF8] text-[#5C2750] text-xs font-medium uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#8C467C]" />
            <span>Build Your Style Quiz</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-medium text-[#2D1527]">
            {currentStep <= 4 ? 'Personal Modest Outfit Curator' : 'Your Custom Curated Look'}
          </h2>
          <p className="text-xs sm:text-sm text-[#7B4C72] mt-1">
            {currentStep <= 4
              ? `Step ${currentStep} of 4: Answer 4 quick styling questions to reveal your look.`
              : 'Here is your personalized outfit ensemble based on your style choices.'}
          </p>

          {/* Progress dots */}
          {currentStep <= 4 && (
            <div className="flex items-center space-x-2 mt-4">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    step === currentStep
                      ? 'w-8 bg-[#5C2750]'
                      : step < currentStep
                      ? 'w-4 bg-[#B283D4]'
                      : 'w-4 bg-[#EBDCF6]'
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {/* STEP 1: VIBE */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-[#5C2750]">
              1. What aesthetic or mood resonates with you?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {VIBE_OPTIONS.map((opt) => {
                const isSelected = answers.vibe === opt.title;
                return (
                  <button
                    key={opt.title}
                    onClick={() => setAnswers({ ...answers, vibe: opt.title })}
                    className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#5C2750] bg-[#FAF3FC] ring-2 ring-[#5C2750]/20 shadow-xs'
                        : 'border-[#EBDCF6] hover:border-[#DEC4EF] bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-serif text-base font-medium text-[#2D1527]">
                        {opt.title}
                      </h4>
                      {isSelected && <Check className="w-4 h-4 text-[#5C2750]" />}
                    </div>
                    <p className="text-xs text-[#7A5370] leading-relaxed">
                      {opt.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 2: COLORS */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-[#5C2750]">
              2. Which color palette do you prefer?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {COLOR_OPTIONS.map((opt) => {
                const isSelected = answers.colors === opt.title;
                return (
                  <button
                    key={opt.title}
                    onClick={() => setAnswers({ ...answers, colors: opt.title })}
                    className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#5C2750] bg-[#FAF3FC] ring-2 ring-[#5C2750]/20 shadow-xs'
                        : 'border-[#EBDCF6] hover:border-[#DEC4EF] bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-serif text-base font-medium text-[#2D1527]">
                        {opt.title}
                      </h4>
                      {isSelected && <Check className="w-4 h-4 text-[#5C2750]" />}
                    </div>
                    <p className="text-xs text-[#7A5370] leading-relaxed">
                      {opt.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 3: OCCASION */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-[#5C2750]">
              3. Where are you going?
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {OCCASIONS_LIST.map((occ) => {
                const isSelected = answers.occasion === occ;
                return (
                  <button
                    key={occ}
                    onClick={() => setAnswers({ ...answers, occasion: occ })}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#5C2750] bg-[#FAF3FC] text-[#2D1527] font-semibold ring-2 ring-[#5C2750]/20 shadow-xs'
                        : 'border-[#EBDCF6] hover:border-[#DEC4EF] text-[#5C2750] bg-white'
                    }`}
                  >
                    <span className="text-xs">{occ}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 4: BUDGET */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-[#5C2750]">
              4. What budget range are you targeting?
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { key: 'affordable' as Budget, title: 'Affordable', symbol: '$', desc: 'Budget-friendly staples & smart finds' },
                { key: 'mid' as Budget, title: 'Mid-Range', symbol: '$$', desc: 'Quality fabrics, silk touches & durable cuts' },
                { key: 'high fashion' as Budget, title: 'High Fashion', symbol: '$$$', desc: 'Opulent pieces, statement gowns & luxury sets' },
              ].map((b) => {
                const isSelected = answers.budget === b.key;
                return (
                  <button
                    key={b.key}
                    onClick={() => setAnswers({ ...answers, budget: b.key })}
                    className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#5C2750] bg-[#FAF3FC] ring-2 ring-[#5C2750]/20 shadow-xs'
                        : 'border-[#EBDCF6] hover:border-[#DEC4EF] bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-serif text-base font-medium text-[#2D1527]">
                        {b.title}
                      </span>
                      <span className="font-mono text-sm font-bold text-[#5C2750]">{b.symbol}</span>
                    </div>
                    <p className="text-xs text-[#7A5370]">{b.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* RESULT CARD (STEP 5) */}
        {currentStep === 5 && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#FAF3FC] via-white to-[#F5EBF9] border border-[#DEC4EF] rounded-3xl p-5 sm:p-6 shadow-sm">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="px-3 py-1 bg-[#2D1527] text-white text-xs rounded-full font-medium uppercase tracking-wider">
                  {answers.occasion}
                </span>
                <span className="px-2.5 py-1 bg-[#EBDCF6] text-[#5C2750] text-xs rounded-full font-medium">
                  {answers.vibe}
                </span>
                <span className="px-2.5 py-1 bg-white border border-[#EBDCF6] text-[#7A5370] text-xs rounded-full font-medium">
                  {answers.colors}
                </span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl font-normal text-[#2D1527] mt-2 mb-2">
                {styleTitle}
              </h3>

              <p className="text-xs sm:text-sm text-[#664060] leading-relaxed mb-5 italic">
                &ldquo;{stylingTips}&rdquo;
              </p>

              {/* Matched pieces preview */}
              <div className="space-y-2.5">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-[#7A5370] block">
                  Curated Outfit Ensemble:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {curatedPieces.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center space-x-3 p-2.5 rounded-2xl bg-white border border-[#EBDCF6]"
                    >
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-12 h-14 object-cover rounded-xl shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <span className="text-[10px] uppercase font-semibold text-[#8C467C] block truncate">
                          {p.category}
                        </span>
                        <h5 className="font-serif text-xs font-medium text-[#2D1527] truncate">
                          {p.name}
                        </h5>
                        <a
                          href={p.buyUrl}
                          target="_blank"
                          rel="sponsored noopener noreferrer"
                          className="text-[11px] text-[#5C2750] font-semibold hover:underline inline-flex items-center space-x-1 mt-0.5"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Buy on {p.store}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions: "Save this look" button + links */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                onClick={handleResetQuiz}
                className="inline-flex items-center space-x-1.5 text-xs text-[#7A5370] hover:text-[#2D1527] cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Start over</span>
              </button>

              <div className="flex items-center space-x-3 w-full sm:w-auto">
                <button
                  onClick={handleSaveThisLook}
                  disabled={isSaved}
                  className={`flex-1 sm:flex-initial inline-flex items-center justify-center space-x-2 px-6 py-3 rounded-full text-sm font-medium transition-all shadow-sm cursor-pointer ${
                    isSaved
                      ? 'bg-[#EBDCF6] text-[#5C2750]'
                      : 'bg-[#2D1527] hover:bg-[#441D3A] text-white active:scale-95'
                  }`}
                >
                  {isSaved ? (
                    <>
                      <BookmarkCheck className="w-4 h-4 text-[#5C2750]" />
                      <span>Saved to My Style!</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-[#DEC4EF]" />
                      <span>Save this look</span>
                    </>
                  )}
                </button>

                {isSaved && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenMyStyle();
                    }}
                    className="inline-flex items-center space-x-1 px-4 py-3 rounded-full bg-[#FAF7FC] hover:bg-[#F2E5F8] text-[#5C2750] text-xs font-semibold border border-[#DEC4EF]"
                  >
                    <span>View in My Style</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons for Steps 1-4 */}
        {currentStep <= 4 && (
          <div className="flex items-center justify-between pt-6 mt-6 border-t border-[#F2E5F8]">
            <button
              onClick={() => setCurrentStep((prev) => Math.max(1, prev - 1))}
              disabled={currentStep === 1}
              className={`inline-flex items-center space-x-1 px-4 py-2 rounded-full text-xs font-medium transition-colors ${
                currentStep === 1
                  ? 'text-[#BCA2BD] cursor-not-allowed'
                  : 'text-[#5C2750] hover:bg-[#F4EBF8] cursor-pointer'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>

            <button
              onClick={() => setCurrentStep((prev) => prev + 1)}
              className="inline-flex items-center space-x-1.5 px-6 py-2.5 rounded-full bg-[#2D1527] hover:bg-[#441D3A] text-white text-xs font-medium transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              <span>{currentStep === 4 ? 'Reveal My Outfit' : 'Next Question'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
