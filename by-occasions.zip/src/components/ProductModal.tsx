import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import {
  X,
  Play,
  ExternalLink,
  Heart,
  Plus,
  Check,
  ShoppingBag,
  Sparkles,
  Video,
  AlertCircle,
} from 'lucide-react';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  isInMyStyle: boolean;
  onToggleWishlist: (product: Product) => void;
  onToggleMyStyle: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  isInMyStyle,
  onToggleWishlist,
  onToggleMyStyle,
}) => {
  const [showEmbeddedVideo, setShowEmbeddedVideo] = useState<boolean>(false);
  const [embedLoadError, setEmbedLoadError] = useState<boolean>(false);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  // Reset video state when product changes
  useEffect(() => {
    setShowEmbeddedVideo(false);
    setEmbedLoadError(false);
  }, [product]);

  if (!isOpen || !product) return null;

  const hasEmbed = Boolean(product.reviewEmbedUrl && product.reviewEmbedUrl.trim().length > 0);

  const handleWatchReviewClick = () => {
    if (hasEmbed) {
      setShowEmbeddedVideo(true);
    } else {
      // If no embed or empty, open reviewUrl in a new tab
      window.open(product.reviewUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleBuyClick = () => {
    // Open affiliate link in new tab with rel="sponsored noopener"
    window.open(product.buyUrl, '_blank', 'sponsored,noopener,noreferrer');
  };

  const budgetLabel =
    product.budget === 'affordable'
      ? 'Affordable ($)'
      : product.budget === 'mid'
      ? 'Mid-Range ($$)'
      : 'High Fashion ($$$)';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div
        className="fixed inset-0"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-[#DEC4EF] z-10 flex flex-col md:flex-row max-h-[92vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/90 backdrop-blur-md text-[#2D1527] hover:bg-[#F2E5F8] transition-colors shadow-xs focus:outline-none"
          aria-label="Close details"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Side: Product Image & Embed Video */}
        <div className="relative md:w-1/2 bg-[#FAF7FC] min-h-[300px] md:min-h-[460px] flex items-center justify-center overflow-hidden border-b md:border-b-0 md:border-r border-[#EBDCF6]">
          {showEmbeddedVideo && hasEmbed && !embedLoadError ? (
            <div className="relative w-full h-full min-h-[360px] bg-black flex flex-col items-center justify-center">
              <iframe
                src={product.reviewEmbedUrl}
                title={`${product.name} Video Review`}
                className="w-full h-full min-h-[360px] border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                onError={() => setEmbedLoadError(true)}
              />
              <button
                onClick={() => setShowEmbeddedVideo(false)}
                className="absolute top-3 left-3 px-3 py-1 bg-black/70 hover:bg-black text-white text-xs rounded-full backdrop-blur-sm"
              >
                Back to photo
              </button>
            </div>
          ) : (
            <div className="relative w-full h-full">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover object-center max-h-[480px]"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=900&auto=format&fit=crop';
                }}
              />

              {/* Tag Overlays */}
              <div className="absolute top-4 left-4 flex flex-col gap-1.5 items-start">
                <span className="px-3 py-1 text-xs font-semibold uppercase tracking-wider bg-white/95 text-[#2D1527] rounded-full shadow-xs">
                  {product.occasion}
                </span>
                <span
                  className={`px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider rounded-md shadow-xs ${
                    product.store === 'Shopee'
                      ? 'bg-[#EE4D2D] text-white'
                      : 'bg-[#232F3E] text-[#FF9900]'
                  }`}
                >
                  {product.store}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Product Details & Primary Two Actions */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Category & Budget */}
            <div className="flex items-center justify-between text-xs font-medium text-[#7A5370] mb-2 uppercase tracking-wide">
              <span>{product.category}</span>
              <span className="font-mono text-[#5C2750]">{budgetLabel}</span>
            </div>

            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-[#2D1527] leading-snug mb-3">
              {product.name}
            </h2>

            <div className="flex items-center space-x-2 text-sm text-[#5C2750] mb-4">
              <span className="font-medium">Color / Fabric:</span>
              <span className="text-[#2D1527]">{product.color}</span>
            </div>

            {product.description && (
              <p className="text-sm text-[#664060] leading-relaxed mb-6 bg-[#FAF7FC] p-3.5 rounded-xl border border-[#EBDCF6]">
                {product.description}
              </p>
            )}

            {/* Quick Stylist Tips */}
            <div className="flex items-center space-x-2 text-xs text-[#7B4C72] mb-6">
              <Sparkles className="w-4 h-4 text-[#8C467C] shrink-0" />
              <span>Perfect pairing for {product.occasion.toLowerCase()} styling and graceful coverage.</span>
            </div>
          </div>

          {/* TWO PRIMARY MANDATORY BUTTONS:
              1. "Watch review"
              2. "Buy on Shopee" or "Buy on Amazon"
          */}
          <div className="space-y-3 pt-4 border-t border-[#F2E5F8]">
            {/* 1. Watch Review Button */}
            <div>
              <button
                onClick={handleWatchReviewClick}
                className="w-full inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-[#F4EBF8] hover:bg-[#EBDCF6] text-[#2D1527] font-medium text-sm transition-all border border-[#DFCAF0] shadow-xs active:scale-[0.99] cursor-pointer"
              >
                <Video className="w-4 h-4 text-[#8C467C]" />
                <span>Watch review</span>
                {!hasEmbed && (
                  <ExternalLink className="w-3.5 h-3.5 text-[#7B4C72] ml-1" />
                )}
              </button>
              {embedLoadError && (
                <div className="mt-1 text-center">
                  <a
                    href={product.reviewUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#8C467C] underline hover:text-[#5C2750] inline-flex items-center space-x-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>Embed unavailable. Click to open review video directly</span>
                  </a>
                </div>
              )}
            </div>

            {/* 2. Buy on Shopee or Buy on Amazon Button */}
            <button
              onClick={handleBuyClick}
              className={`w-full inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl text-white font-medium text-sm transition-all shadow-sm active:scale-[0.99] cursor-pointer ${
                product.store === 'Shopee'
                  ? 'bg-[#EE4D2D] hover:bg-[#d43d1f]'
                  : 'bg-[#232F3E] hover:bg-[#131921] text-[#FF9900]'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Buy on {product.store}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-1 opacity-80" />
            </button>

            {/* Affiliate Link disclaimer */}
            <p className="text-[10px] text-center text-[#8C6D85]">
              Affiliate link will open in a new tab. No payment or checkout on this site.
            </p>

            {/* Secondary Actions: Wishlist and Add to My Style */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => onToggleWishlist(product)}
                className="inline-flex items-center justify-center space-x-1.5 px-3 py-2 rounded-lg border border-[#E4CEF2] text-xs font-medium text-[#2D1527] hover:bg-[#FAF7FC] transition-colors cursor-pointer"
              >
                <Heart
                  className={`w-3.5 h-3.5 ${
                    isWishlisted ? 'text-[#9A3978] fill-[#9A3978]' : 'text-[#63435B]'
                  }`}
                />
                <span>{isWishlisted ? 'Wishlisted' : 'Save Item'}</span>
              </button>

              <button
                onClick={() => onToggleMyStyle(product)}
                className={`inline-flex items-center justify-center space-x-1.5 px-3 py-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                  isInMyStyle
                    ? 'border-[#B283D4] bg-[#F4EBF8] text-[#5C2750]'
                    : 'border-[#E4CEF2] text-[#2D1527] hover:bg-[#FAF7FC]'
                }`}
              >
                {isInMyStyle ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#5C2750]" />
                    <span>In My Style</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5 text-[#5C2750]" />
                    <span>Add to my style</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
