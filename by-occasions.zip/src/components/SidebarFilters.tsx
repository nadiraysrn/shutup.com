import React from 'react';
import { Occasion, Category, Budget } from '../types';
import { OCCASIONS_LIST } from '../productsData';
import { SlidersHorizontal, Sparkles, X, Search } from 'lucide-react';

interface SidebarFiltersProps {
  selectedOccasion: Occasion | 'All';
  onSelectOccasion: (occ: Occasion | 'All') => void;
  selectedCategory: Category | 'All';
  onSelectCategory: (cat: Category | 'All') => void;
  selectedBudget: Budget | 'All';
  onSelectBudget: (b: Budget | 'All') => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  countsByOccasion: Record<string, number>;
  totalCount: number;
  onResetFilters: () => void;
}

const CATEGORIES: Array<{ key: Category | 'All'; label: string }> = [
  { key: 'All', label: 'All Items' },
  { key: 'dress', label: 'Dresses' },
  { key: 'set', label: 'Sets & Co-ords' },
  { key: 'hijab', label: 'Hijabs & Scarves' },
  { key: 'top', label: 'Tops & Blazers' },
  { key: 'bottom', label: 'Bottoms' },
  { key: 'shoes', label: 'Shoes' },
  { key: 'accessories', label: 'Accessories' },
];

const BUDGETS: Array<{ key: Budget | 'All'; label: string; symbol: string }> = [
  { key: 'All', label: 'All Budgets', symbol: '•' },
  { key: 'affordable', label: 'Affordable', symbol: '$' },
  { key: 'mid', label: 'Mid-Range', symbol: '$$' },
  { key: 'high fashion', label: 'High Fashion', symbol: '$$$' },
];

export const SidebarFilters: React.FC<SidebarFiltersProps> = ({
  selectedOccasion,
  onSelectOccasion,
  selectedCategory,
  onSelectCategory,
  selectedBudget,
  onSelectBudget,
  searchQuery,
  onSearchChange,
  countsByOccasion,
  totalCount,
  onResetFilters,
}) => {
  const isFiltered =
    selectedOccasion !== 'All' ||
    selectedCategory !== 'All' ||
    selectedBudget !== 'All' ||
    searchQuery.trim().length > 0;

  return (
    <>
      {/* =========================================================================
          MOBILE VIEW: Horizontally scrollable occasion bar above products
          ========================================================================= */}
      <div className="lg:hidden w-full mb-6 space-y-3">
        {/* Search bar mobile */}
        <div className="relative">
          <Search className="w-4 h-4 text-[#8C467C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search modesty looks, fabric, store..."
            className="w-full pl-9 pr-8 py-2 text-sm bg-white border border-[#E4CEF2] rounded-full text-[#2D1527] placeholder:text-[#9A7394] focus:outline-none focus:ring-2 focus:ring-[#B283D4]"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8C467C] hover:text-[#2D1527]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Scrollable Occasion Bar */}
        <div>
          <div className="flex items-center justify-between mb-1.5 px-1">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#664060]">
              Filter Occasion
            </span>
            {isFiltered && (
              <button
                onClick={onResetFilters}
                className="text-xs text-[#8C467C] hover:underline cursor-pointer"
              >
                Reset
              </button>
            )}
          </div>
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar pb-2 pt-1 -mx-4 px-4 sm:mx-0 sm:px-0">
            <button
              onClick={() => onSelectOccasion('All')}
              className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer ${
                selectedOccasion === 'All'
                  ? 'bg-[#2D1527] text-white shadow-xs'
                  : 'bg-white text-[#5C2750] border border-[#E2CEEF] hover:bg-[#F3E7F8]'
              }`}
            >
              All Occasions ({totalCount})
            </button>
            {OCCASIONS_LIST.map((occ) => {
              const count = countsByOccasion[occ] || 0;
              const isSelected = selectedOccasion === occ;
              return (
                <button
                  key={occ}
                  onClick={() => onSelectOccasion(occ)}
                  className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#2D1527] text-white shadow-xs'
                      : 'bg-white text-[#5C2750] border border-[#E2CEEF] hover:bg-[#F3E7F8]'
                  }`}
                >
                  {occ} <span className="opacity-70 text-[10px]">({count})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick mobile category chips */}
        <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              onClick={() => onSelectCategory(cat.key)}
              className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                selectedCategory === cat.key
                  ? 'bg-[#EBDCF6] text-[#2D1527] font-semibold'
                  : 'text-[#6B4B65] hover:text-[#2D1527] bg-[#F7F2FA]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* =========================================================================
          DESKTOP VIEW: Dedicated Left Sidebar
          ========================================================================= */}
      <aside className="hidden lg:block w-64 shrink-0">
        <div className="sticky top-28 bg-white/70 backdrop-blur-sm border border-[#EBDCF6] rounded-2xl p-5 shadow-xs space-y-6">
          {/* Header & Reset */}
          <div className="flex items-center justify-between pb-3 border-b border-[#F0E2F7]">
            <div className="flex items-center space-x-2">
              <SlidersHorizontal className="w-4 h-4 text-[#8C467C]" />
              <h2 className="font-serif text-lg font-medium text-[#2D1527]">
                Occasions
              </h2>
            </div>
            {isFiltered && (
              <button
                onClick={onResetFilters}
                className="text-xs text-[#8C467C] hover:text-[#2D1527] hover:underline cursor-pointer"
              >
                Clear all
              </button>
            )}
          </div>

          {/* Search Bar Desktop */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#8C467C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search pieces..."
              className="w-full pl-9 pr-7 py-1.5 text-xs bg-[#FAF7FC] border border-[#E4CEF2] rounded-lg text-[#2D1527] placeholder:text-[#9A7394] focus:outline-none focus:ring-1 focus:ring-[#8C467C]"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8C467C] hover:text-[#2D1527]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Primary Occasion List */}
          <div>
            <span className="block text-[11px] uppercase tracking-wider font-semibold text-[#7D5377] mb-2">
              Select Occasion
            </span>
            <div className="space-y-1">
              <button
                onClick={() => onSelectOccasion('All')}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all text-left cursor-pointer ${
                  selectedOccasion === 'All'
                    ? 'bg-[#2D1527] text-white shadow-xs font-semibold'
                    : 'text-[#5C2750] hover:bg-[#F6EDFA]'
                }`}
              >
                <span>All Occasions</span>
                <span
                  className={`text-[11px] px-1.5 py-0.5 rounded-full ${
                    selectedOccasion === 'All' ? 'bg-white/20 text-white' : 'bg-[#EBDCF6] text-[#5C2750]'
                  }`}
                >
                  {totalCount}
                </span>
              </button>

              {OCCASIONS_LIST.map((occ) => {
                const count = countsByOccasion[occ] || 0;
                const isSelected = selectedOccasion === occ;
                return (
                  <button
                    key={occ}
                    onClick={() => onSelectOccasion(occ)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all text-left cursor-pointer ${
                      isSelected
                        ? 'bg-[#2D1527] text-white shadow-xs font-semibold'
                        : 'text-[#5C2750] hover:bg-[#F6EDFA]'
                    }`}
                  >
                    <span>{occ}</span>
                    <span
                      className={`text-[11px] px-1.5 py-0.5 rounded-full ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-[#EBDCF6] text-[#5C2750]'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Category Filter */}
          <div className="pt-4 border-t border-[#F0E2F7]">
            <span className="block text-[11px] uppercase tracking-wider font-semibold text-[#7D5377] mb-2">
              Category
            </span>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.key}
                  onClick={() => onSelectCategory(cat.key)}
                  className={`px-2.5 py-1 text-xs rounded-lg transition-colors cursor-pointer ${
                    selectedCategory === cat.key
                      ? 'bg-[#5C2750] text-white font-medium'
                      : 'bg-[#FAF7FC] text-[#5C2750] hover:bg-[#F2E5F8] border border-[#EBDCF6]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Budget Filter */}
          <div className="pt-4 border-t border-[#F0E2F7]">
            <span className="block text-[11px] uppercase tracking-wider font-semibold text-[#7D5377] mb-2">
              Budget Tier
            </span>
            <div className="space-y-1">
              {BUDGETS.map((b) => (
                <button
                  key={b.key}
                  onClick={() => onSelectBudget(b.key)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                    selectedBudget === b.key
                      ? 'bg-[#EBDCF6] text-[#2D1527] font-semibold'
                      : 'text-[#664060] hover:bg-[#FAF7FC]'
                  }`}
                >
                  <span>{b.label}</span>
                  <span className="text-[11px] font-mono text-[#8C467C]">{b.symbol}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Editorial Callout */}
          <div className="p-3 bg-[#FAF3FC] border border-[#ECD7F5] rounded-xl text-center">
            <Sparkles className="w-4 h-4 text-[#8C467C] mx-auto mb-1" />
            <p className="text-[11px] text-[#5C2750] leading-snug font-medium">
              Not sure which match fits you?
            </p>
            <p className="text-[10px] text-[#7D5377] mt-0.5">
              Try the 4-question style builder above.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
