import React, { useState, useEffect } from 'react';
import { Product, Occasion, SavedLook } from '../types';
import { OCCASIONS_LIST } from '../productsData';
import {
  X,
  Heart,
  Trash2,
  ExternalLink,
  Video,
  ShoppingBag,
  Sparkles,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  myStyleProducts: Product[];
  onRemoveFromMyStyle: (productId: string) => void;
  savedLooks: SavedLook[];
  onDeleteSavedLook: (lookId: string) => void;
  onSelectProduct: (product: Product) => void;
  onOpenQuiz: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveFromWishlist,
  myStyleProducts,
  onRemoveFromMyStyle,
  savedLooks,
  onDeleteSavedLook,
  onSelectProduct,
  onOpenQuiz,
}) => {
  // Tabs: 'All' | Occasion | 'My Style'
  type TabType = 'All' | Occasion | 'My Style';
  const [activeTab, setActiveTab] = useState<TabType>('All');

  // Prevent background scroll and support ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Filter items according to the active tab
  let displayedItems: Product[] = [];
  if (activeTab === 'All') {
    displayedItems = wishlistProducts;
  } else if (activeTab === 'My Style') {
    // In "My Style" tab we will display both saved looks and individually added style items
    displayedItems = myStyleProducts;
  } else {
    displayedItems = wishlistProducts.filter((p) => p.occasion === activeTab);
  }

  const handleWatchReview = (p: Product) => {
    if (p.reviewEmbedUrl && p.reviewEmbedUrl.trim().length > 0) {
      onSelectProduct(p);
    } else {
      window.open(p.reviewUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleBuy = (p: Product) => {
    window.open(p.buyUrl, '_blank', 'sponsored,noopener,noreferrer');
  };

  const tabs: Array<{ id: TabType; label: string; count?: number }> = [
    { id: 'All', label: 'All', count: wishlistProducts.length },
    ...OCCASIONS_LIST.map((occ) => ({
      id: occ,
      label: occ,
      count: wishlistProducts.filter((p) => p.occasion === occ).length,
    })),
    {
      id: 'My Style',
      label: 'My Style',
      count: myStyleProducts.length + savedLooks.length,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Drawer Panel */}
      <div className="relative w-full max-w-2xl bg-[#FAF7FC] h-full shadow-2xl flex flex-col z-10 border-l border-[#DEC4EF]">
        {/* Drawer Header */}
        <div className="p-5 sm:p-6 bg-white border-b border-[#EBDCF6] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#F6EDFA] rounded-full text-[#9A3978]">
              <Heart className="w-5 h-5 fill-[#9A3978]" />
            </div>
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-medium text-[#2D1527]">
                My Wishlist & Looks
              </h2>
              <p className="text-xs text-[#7B4C72]">
                {wishlistProducts.length} saved piece{wishlistProducts.length === 1 ? '' : 's'} across occasions
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-[#63435B] hover:text-[#2D1527] hover:bg-[#F2E5F8] transition-colors focus:outline-none"
            aria-label="Close wishlist"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation: All, one tab per occasion, and "My Style" */}
        <div className="bg-white border-b border-[#EBDCF6] px-4 sm:px-6">
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar py-2.5">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#2D1527] text-white shadow-xs'
                      : 'bg-[#FAF7FC] text-[#5C2750] border border-[#E4CEF2] hover:bg-[#F2E5F8]'
                  }`}
                >
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span
                      className={`ml-1.5 text-[10px] px-1.5 py-0.2 rounded-full ${
                        isActive ? 'bg-white/20 text-white' : 'bg-[#EBDCF6] text-[#5C2750]'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* SPECIAL TAB: MY STYLE */}
          {activeTab === 'My Style' ? (
            <div className="space-y-6">
              {/* Header inside My Style */}
              <div className="p-4 bg-gradient-to-r from-[#F6EDFA] to-[#F1E0F8] border border-[#E2CEEF] rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center space-x-1.5 text-[#5C2750] font-medium text-xs mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Personal Wardrobe Studio</span>
                  </div>
                  <h3 className="font-serif text-lg text-[#2D1527]">My Style Board</h3>
                  <p className="text-xs text-[#7B4C72] mt-0.5">
                    Curated looks saved from the Style Quiz and items added via &apos;Add to my style&apos;.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenQuiz();
                  }}
                  className="px-3 py-1.5 bg-[#2D1527] text-white rounded-full text-xs font-medium hover:bg-[#441D3A] transition-colors shrink-0"
                >
                  Create new look
                </button>
              </div>

              {/* Saved Looks List */}
              {savedLooks.length > 0 && (
                <div className="space-y-4">
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-[#664060]">
                    Saved Outfits from Quiz ({savedLooks.length})
                  </h4>
                  {savedLooks.map((look) => (
                    <div
                      key={look.id}
                      className="bg-white border border-[#EBDCF6] rounded-2xl p-4 shadow-xs hover:border-[#D5B7EA] transition-all"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#EBDCF6] text-[#5C2750]">
                              {look.occasion}
                            </span>
                            <span className="text-xs text-[#7A5370]">Vibe: {look.vibe}</span>
                          </div>
                          <h5 className="font-serif text-base text-[#2D1527] mt-1 font-medium">
                            {look.title}
                          </h5>
                          {look.stylingNote && (
                            <p className="text-xs text-[#63435B] mt-1 italic">
                              &ldquo;{look.stylingNote}&rdquo;
                            </p>
                          )}
                        </div>
                        <button
                          onClick={() => onDeleteSavedLook(look.id)}
                          className="p-1.5 text-[#9A7394] hover:text-red-600 rounded-lg transition-colors"
                          title="Delete saved look"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Display products in this look */}
                      <div className="mt-3 pt-3 border-t border-[#F4EBF8]">
                        <span className="text-[11px] font-medium text-[#7A5370] block mb-2">
                          Pieces in this outfit:
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {wishlistProducts
                            .concat(myStyleProducts)
                            .filter((p, idx, arr) => arr.findIndex(x => x.id === p.id) === idx)
                            .filter((p) => look.itemIds.includes(p.id))
                            .map((item) => (
                              <div
                                key={item.id}
                                className="flex items-center space-x-2.5 p-2 rounded-xl bg-[#FAF7FC] border border-[#EBDCF6]"
                              >
                                <img
                                  src={item.image}
                                  alt={item.name}
                                  className="w-10 h-10 rounded-lg object-cover"
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="text-xs font-medium text-[#2D1527] truncate">
                                    {item.name}
                                  </p>
                                  <div className="flex items-center space-x-2 mt-0.5">
                                    <button
                                      onClick={() => handleBuy(item)}
                                      className="text-[10px] text-[#5C2750] font-semibold hover:underline inline-flex items-center"
                                    >
                                      Buy on {item.store}
                                      <ExternalLink className="w-2.5 h-2.5 ml-0.5" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Individually added items in "My Style" */}
              <div>
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#664060] mb-3">
                  Individual Pieces in My Style ({myStyleProducts.length})
                </h4>

                {myStyleProducts.length === 0 && savedLooks.length === 0 ? (
                  <div className="text-center py-12 px-4 bg-white rounded-2xl border border-dashed border-[#DEC4EF]">
                    <Layers className="w-8 h-8 text-[#B283D4] mx-auto mb-2" />
                    <h5 className="font-serif text-lg text-[#2D1527]">
                      Your style board is empty
                    </h5>
                    <p className="text-xs text-[#7A5370] max-w-xs mx-auto mt-1 mb-4">
                      Tap &apos;Add to my style&apos; on any product card or take the quiz to curate your look.
                    </p>
                    <button
                      onClick={() => {
                        onClose();
                        onOpenQuiz();
                      }}
                      className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-full bg-[#2D1527] text-white text-xs font-medium hover:bg-[#441D3A]"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Take Style Quiz</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myStyleProducts.map((p) => (
                      <WishlistItemRow
                        key={p.id}
                        product={p}
                        onRemove={() => onRemoveFromMyStyle(p.id)}
                        onWatchReview={() => handleWatchReview(p)}
                        onBuy={() => handleBuy(p)}
                        onClickProduct={() => onSelectProduct(p)}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* STANDARD WISHLIST ITEMS LIST */
            <div>
              {displayedItems.length === 0 ? (
                <div className="text-center py-16 px-4 bg-white rounded-2xl border border-dashed border-[#DEC4EF]">
                  <Heart className="w-10 h-10 text-[#DEC4EF] mx-auto mb-2" />
                  <h4 className="font-serif text-xl text-[#2D1527]">
                    No items saved in {activeTab === 'All' ? 'your wishlist' : activeTab}
                  </h4>
                  <p className="text-xs text-[#7A5370] max-w-xs mx-auto mt-1 mb-4">
                    Click the heart icon on any product to save it here for later.
                  </p>
                  <button
                    onClick={onClose}
                    className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-full bg-[#2D1527] text-white text-xs font-medium hover:bg-[#441D3A]"
                  >
                    <span>Browse Outfits</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {displayedItems.map((p) => (
                    <WishlistItemRow
                      key={p.id}
                      product={p}
                      onRemove={() => onRemoveFromWishlist(p.id)}
                      onWatchReview={() => handleWatchReview(p)}
                      onBuy={() => handleBuy(p)}
                      onClickProduct={() => onSelectProduct(p)}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Drawer Footer with Affiliate Note */}
        <div className="p-4 bg-white border-t border-[#EBDCF6] text-center">
          <p className="text-[11px] text-[#7B4C72]">
            Affiliate links open directly on {activeTab === 'My Style' ? 'Shopee or Amazon' : 'store sites'} with sponsored tags.
          </p>
        </div>
      </div>
    </div>
  );
};

// Sub-component for individual item in wishlist
interface WishlistItemRowProps {
  product: Product;
  onRemove: () => void;
  onWatchReview: () => void;
  onBuy: () => void;
  onClickProduct: () => void;
}

const WishlistItemRow: React.FC<WishlistItemRowProps> = ({
  product,
  onRemove,
  onWatchReview,
  onBuy,
  onClickProduct,
}) => {
  return (
    <div className="bg-white border border-[#EBDCF6] rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs hover:border-[#D5B7EA] transition-all">
      {/* Product Thumbnail & Info */}
      <div
        onClick={onClickProduct}
        className="flex items-center space-x-3 cursor-pointer group flex-1 min-w-0"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-16 h-20 sm:w-14 sm:h-18 object-cover rounded-xl bg-[#FAF7FC] shrink-0 group-hover:scale-105 transition-transform"
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center space-x-2 text-[10px] font-medium text-[#7B4C72] uppercase tracking-wider mb-0.5">
            <span>{product.occasion}</span>
            <span>•</span>
            <span>{product.category}</span>
          </div>
          <h4 className="font-serif text-sm font-medium text-[#2D1527] truncate group-hover:text-[#5C2750]">
            {product.name}
          </h4>
          <p className="text-xs text-[#8C6D85] truncate mt-0.5">
            {product.color}
          </p>
        </div>
      </div>

      {/* Action Buttons: "Watch review" and "Buy on Shopee/Amazon" + Remove */}
      <div className="flex items-center space-x-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-[#F4EBF8]">
        {/* Watch review button */}
        <button
          onClick={onWatchReview}
          className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#F4EBF8] hover:bg-[#EBDCF6] text-[#2D1527] text-xs font-medium transition-colors cursor-pointer"
        >
          <Video className="w-3.5 h-3.5 text-[#8C467C]" />
          <span>Watch review</span>
        </button>

        {/* Buy on Shopee or Buy on Amazon button */}
        <button
          onClick={onBuy}
          className={`inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg text-white text-xs font-medium transition-colors cursor-pointer ${
            product.store === 'Shopee'
              ? 'bg-[#EE4D2D] hover:bg-[#d43d1f]'
              : 'bg-[#232F3E] hover:bg-[#131921] text-[#FF9900]'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Buy on {product.store}</span>
          <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
        </button>

        {/* Remove button */}
        <button
          onClick={onRemove}
          className="p-1.5 text-[#9A7394] hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors ml-1 cursor-pointer"
          title="Remove from wishlist"
          aria-label="Remove item"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
