import React from 'react';
import { Product } from '../types';
import { Heart, Plus, ExternalLink, Play, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  isInMyStyle: boolean;
  onToggleWishlist: (e: React.MouseEvent, product: Product) => void;
  onToggleMyStyle: (e: React.MouseEvent, product: Product) => void;
  onClickCard: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  isInMyStyle,
  onToggleWishlist,
  onToggleMyStyle,
  onClickCard,
}) => {
  const budgetSymbol =
    product.budget === 'affordable'
      ? '$'
      : product.budget === 'mid'
      ? '$$'
      : '$$$';

  return (
    <article
      onClick={() => onClickCard(product)}
      className="group relative flex flex-col bg-white border border-[#EBDCF6] rounded-2xl overflow-hidden hover:shadow-md hover:border-[#D5B7EA] transition-all duration-300 cursor-pointer"
    >
      {/* Image container */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-[#FAF7FC]">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // Fallback gracefully if image fails
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=900&auto=format&fit=crop';
          }}
        />

        {/* Gradient vignette at bottom of image */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        {/* Occasion & Store tags */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
          <span className="px-2.5 py-1 text-[11px] font-medium tracking-wide uppercase bg-white/95 backdrop-blur-sm text-[#2D1527] rounded-full shadow-xs">
            {product.occasion}
          </span>
          <span
            className={`px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider rounded-md shadow-xs ${
              product.store === 'Shopee'
                ? 'bg-[#EE4D2D] text-white'
                : 'bg-[#232F3E] text-[#FF9900]'
            }`}
          >
            {product.store}
          </span>
        </div>

        {/* Top-Right Heart button to save to wishlist */}
        <button
          onClick={(e) => onToggleWishlist(e, product)}
          aria-label={isWishlisted ? 'Remove from Wishlist' : 'Save to Wishlist'}
          className="absolute top-3 right-3 p-2 rounded-full bg-white/90 backdrop-blur-sm hover:bg-white text-[#2D1527] shadow-sm transition-transform active:scale-90 hover:scale-110 focus:outline-none"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isWishlisted
                ? 'text-[#9A3978] fill-[#9A3978]'
                : 'text-[#63435B] hover:text-[#9A3978]'
            }`}
          />
        </button>

        {/* Hover quick action pill at bottom */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-all duration-200 transform translate-y-1 group-hover:translate-y-0">
          <span className="text-[11px] font-medium text-white px-2 py-1 bg-black/60 backdrop-blur-sm rounded-lg flex items-center space-x-1">
            <Play className="w-3 h-3 fill-white" />
            <span>Watch / Buy</span>
          </span>

          {/* Quick Add to My Style button */}
          <button
            onClick={(e) => onToggleMyStyle(e, product)}
            className={`text-[11px] font-medium px-2.5 py-1 rounded-lg backdrop-blur-sm shadow-xs transition-colors flex items-center space-x-1 ${
              isInMyStyle
                ? 'bg-[#EBDCF6] text-[#2D1527]'
                : 'bg-white/95 text-[#2D1527] hover:bg-white'
            }`}
          >
            {isInMyStyle ? (
              <>
                <Check className="w-3 h-3 text-[#5C2750]" />
                <span>In My Style</span>
              </>
            ) : (
              <>
                <Plus className="w-3 h-3 text-[#5C2750]" />
                <span>Add to My Style</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1 justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-[#7B4C72] mb-1">
            <span className="capitalize">{product.category}</span>
            <span className="font-mono font-medium text-[#5C2750]" title={`Budget: ${product.budget}`}>
              {budgetSymbol}
            </span>
          </div>

          <h3 className="font-serif text-base font-normal text-[#2D1527] line-clamp-2 leading-snug group-hover:text-[#5C2750] transition-colors">
            {product.name}
          </h3>

          <p className="text-xs text-[#7A5370] mt-1 line-clamp-1">
            {product.color}
          </p>
        </div>

        {/* Bottom Store link indicator */}
        <div className="mt-3 pt-3 border-t border-[#F2E5F8] flex items-center justify-between text-xs">
          <span className="text-[#63435B] font-medium flex items-center space-x-1">
            <span>View Details</span>
          </span>
          <span className="text-[#8C467C] font-semibold flex items-center space-x-0.5 group-hover:underline">
            <span>{product.store}</span>
            <ExternalLink className="w-3 h-3" />
          </span>
        </div>
      </div>
    </article>
  );
};
