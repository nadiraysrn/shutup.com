import React from 'react';
import { Heart, Sparkles } from 'lucide-react';

interface NavbarProps {
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenQuiz: () => void;
  onScrollToShop: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  wishlistCount,
  onOpenWishlist,
  onOpenQuiz,
  onScrollToShop,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#FAF7FC]/90 backdrop-blur-md border-b border-[#EBDCF6] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo / Brand Name */}
          <button
            onClick={onScrollToShop}
            className="text-left group transition-transform active:scale-[0.99] focus:outline-none"
            aria-label="By Occasions home"
          >
            <div className="flex items-baseline space-x-2">
              <span className="font-serif text-2xl sm:text-3xl font-medium tracking-tight text-[#2D1527] group-hover:text-[#5C2750] transition-colors">
                By Occasions
              </span>
              <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-[#B283D4]" />
            </div>
            <p className="text-[11px] sm:text-xs tracking-wider uppercase text-[#7B4C72] font-sans font-medium">
              Curated Modest Fashion
            </p>
          </button>

          {/* Top-Right Menu: only "Shop", "Build your style", and "My Wishlist" */}
          <nav className="flex items-center space-x-2 sm:space-x-4">
            <button
              onClick={onScrollToShop}
              className="px-3.5 py-2 text-sm font-medium text-[#2D1527] hover:text-[#5C2750] hover:bg-[#F3E7F8] rounded-full transition-colors cursor-pointer"
            >
              Shop
            </button>

            <button
              onClick={onOpenQuiz}
              className="inline-flex items-center space-x-1.5 px-3.5 py-2 text-sm font-medium text-[#5C2750] bg-[#F2E5F8] hover:bg-[#EBD2F5] active:bg-[#E2C3ED] rounded-full transition-all border border-[#DFCAF0] shadow-sm cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#8C467C]" />
              <span className="hidden xs:inline">Build your style</span>
              <span className="xs:hidden">Style Quiz</span>
            </button>

            {/* My Wishlist Button with Heart and Count */}
            <button
              onClick={onOpenWishlist}
              className="relative inline-flex items-center space-x-2 px-3.5 sm:px-4 py-2 text-sm font-medium text-[#2D1527] bg-[#FAF7FC] hover:bg-[#F3E8F9] active:bg-[#EBDCF6] border border-[#DEC4EF] rounded-full transition-all shadow-sm group cursor-pointer"
              aria-label={`My Wishlist with ${wishlistCount} items`}
            >
              <Heart
                className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                  wishlistCount > 0 ? 'text-[#9A3978] fill-[#9A3978]' : 'text-[#5C2750]'
                }`}
              />
              <span className="hidden sm:inline">My Wishlist</span>
              {wishlistCount > 0 && (
                <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 text-[11px] font-bold text-white bg-[#5C2750] rounded-full shadow-xs">
                  {wishlistCount}
                </span>
              )}
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
