/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { Product, Occasion, Category, Budget, SavedLook } from './types';
import { PRODUCTS } from './productsData';
import {
  getStoredWishlist,
  setStoredWishlist,
  getStoredMyStyleItems,
  setStoredMyStyleItems,
  getStoredSavedLooks,
  setStoredSavedLooks,
} from './utils/storage';

import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SidebarFilters } from './components/SidebarFilters';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { StyleQuizModal } from './components/StyleQuizModal';
import { AboutUs } from './components/AboutUs';
import { Footer } from './components/Footer';
import { Sparkles, Layers, SlidersHorizontal, CheckCircle2 } from 'lucide-react';

export default function App() {
  // --- Persistent Storage State ---
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => getStoredWishlist());
  const [myStyleIds, setMyStyleIds] = useState<string[]>(() => getStoredMyStyleItems());
  const [savedLooks, setSavedLooks] = useState<SavedLook[]>(() => getStoredSavedLooks());

  // --- Filtering & Navigation State ---
  const [selectedOccasion, setSelectedOccasion] = useState<Occasion | 'All'>('All');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [selectedBudget, setSelectedBudget] = useState<Budget | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // --- Modal & Drawer States ---
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);

  // --- Toast Notification Feedback ---
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // --- Wishlist Handler ---
  const toggleWishlist = (e?: React.MouseEvent, product?: Product) => {
    if (e) e.stopPropagation();
    if (!product) return;

    setWishlistIds((prev) => {
      const exists = prev.includes(product.id);
      let updated: string[];
      if (exists) {
        updated = prev.filter((id) => id !== product.id);
        showToast(`Removed "${product.name}" from Wishlist`);
      } else {
        updated = [...prev, product.id];
        showToast(`Saved "${product.name}" to Wishlist`);
      }
      setStoredWishlist(updated);
      return updated;
    });
  };

  const removeFromWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const updated = prev.filter((id) => id !== productId);
      setStoredWishlist(updated);
      showToast('Item removed from Wishlist');
      return updated;
    });
  };

  // --- "My Style" Items Handler ---
  const toggleMyStyle = (e?: React.MouseEvent, product?: Product) => {
    if (e) e.stopPropagation();
    if (!product) return;

    setMyStyleIds((prev) => {
      const exists = prev.includes(product.id);
      let updated: string[];
      if (exists) {
        updated = prev.filter((id) => id !== product.id);
        showToast(`Removed from My Style`);
      } else {
        updated = [...prev, product.id];
        showToast(`Added "${product.name}" to My Style`);
      }
      setStoredMyStyleItems(updated);
      return updated;
    });
  };

  const removeFromMyStyle = (productId: string) => {
    setMyStyleIds((prev) => {
      const updated = prev.filter((id) => id !== productId);
      setStoredMyStyleItems(updated);
      showToast('Item removed from My Style');
      return updated;
    });
  };

  // --- Saved Looks Handler (from Quiz) ---
  const handleSaveLook = (newLook: SavedLook) => {
    setSavedLooks((prev) => {
      const updated = [newLook, ...prev];
      setStoredSavedLooks(updated);
      return updated;
    });
    showToast(`Saved look "${newLook.title}" to My Style tab!`);
  };

  const handleDeleteSavedLook = (lookId: string) => {
    setSavedLooks((prev) => {
      const updated = prev.filter((l) => l.id !== lookId);
      setStoredSavedLooks(updated);
      showToast('Look removed from My Style');
      return updated;
    });
  };

  // --- Filtered Products Calculation ---
  const countsByOccasion = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const p of PRODUCTS) {
      counts[p.occasion] = (counts[p.occasion] || 0) + 1;
    }
    return counts;
  }, []);

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      // Occasion filter
      if (selectedOccasion !== 'All' && p.occasion !== selectedOccasion) {
        return false;
      }
      // Category filter
      if (selectedCategory !== 'All' && p.category !== selectedCategory) {
        return false;
      }
      // Budget filter
      if (selectedBudget !== 'All' && p.budget !== selectedBudget) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim().length > 0) {
        const query = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesOccasion = p.occasion.toLowerCase().includes(query);
        const matchesCategory = p.category.toLowerCase().includes(query);
        const matchesColor = p.color.toLowerCase().includes(query);
        const matchesStore = p.store.toLowerCase().includes(query);
        const matchesDesc = (p.description || '').toLowerCase().includes(query);
        if (!matchesName && !matchesOccasion && !matchesCategory && !matchesColor && !matchesStore && !matchesDesc) {
          return false;
        }
      }
      return true;
    });
  }, [selectedOccasion, selectedCategory, selectedBudget, searchQuery]);

  const wishlistProducts = useMemo(() => {
    return PRODUCTS.filter((p) => wishlistIds.includes(p.id));
  }, [wishlistIds]);

  const myStyleProducts = useMemo(() => {
    return PRODUCTS.filter((p) => myStyleIds.includes(p.id));
  }, [myStyleIds]);

  // Section reference for smooth scroll to catalog
  const shopSectionRef = useRef<HTMLDivElement>(null);
  const handleScrollToShop = () => {
    shopSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleResetFilters = () => {
    setSelectedOccasion('All');
    setSelectedCategory('All');
    setSelectedBudget('All');
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-[#FAF7FC] text-[#2D1527] font-sans flex flex-col selection:bg-[#EBDCF6] selection:text-[#2D1527]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-2 px-4 py-2.5 bg-[#2D1527] text-white text-xs font-medium rounded-full shadow-lg border border-[#5C2750] animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-[#dec4ef] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        wishlistCount={wishlistIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onScrollToShop={handleScrollToShop}
      />

      {/* Hero Section with exact user headline & intro */}
      <Hero
        onOpenQuiz={() => setIsQuizOpen(true)}
        onExploreClick={handleScrollToShop}
      />

      {/* Main Content Area: Sidebar on Desktop + Horizontal on Mobile */}
      <main
        ref={shopSectionRef}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-16 w-full flex-1"
      >
        <div className="flex flex-col lg:flex-row gap-8 items-start">
          {/* Left Sidebar Filters (Desktop) & Top Scrollable Bar (Mobile) */}
          <SidebarFilters
            selectedOccasion={selectedOccasion}
            onSelectOccasion={setSelectedOccasion}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            selectedBudget={selectedBudget}
            onSelectBudget={setSelectedBudget}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            countsByOccasion={countsByOccasion}
            totalCount={PRODUCTS.length}
            onResetFilters={handleResetFilters}
          />

          {/* Right Product Grid Area */}
          <section className="flex-1 w-full min-w-0">
            {/* Catalog Header Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-[#EBDCF6]">
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="font-serif text-2xl sm:text-3xl font-medium text-[#2D1527]">
                    {selectedOccasion === 'All' ? 'Curated Collection' : selectedOccasion}
                  </h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#EBDCF6] text-[#5C2750] font-medium">
                    {filteredProducts.length} piece{filteredProducts.length === 1 ? '' : 's'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#7A5370] mt-1">
                  {selectedOccasion === 'All'
                    ? 'Explore pieces curated across all modest dress codes.'
                    : `Specially styled modest choices for ${selectedOccasion.toLowerCase()}.`}
                </p>
              </div>

              {/* Quick helper banner */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsQuizOpen(true)}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-white border border-[#DEC4EF] hover:bg-[#F8F2FB] text-xs font-medium text-[#5C2750] transition-colors shadow-2xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#8C467C]" />
                  <span>Match my vibe</span>
                </button>
              </div>
            </div>

            {/* Product Cards Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    isWishlisted={wishlistIds.includes(product.id)}
                    isInMyStyle={myStyleIds.includes(product.id)}
                    onToggleWishlist={(e) => toggleWishlist(e, product)}
                    onToggleMyStyle={(e) => toggleMyStyle(e, product)}
                    onClickCard={(p) => setSelectedProduct(p)}
                  />
                ))}
              </div>
            ) : (
              /* Empty state if search or filters returned nothing */
              <div className="text-center py-20 px-4 bg-white rounded-3xl border border-dashed border-[#DEC4EF]">
                <SlidersHorizontal className="w-10 h-10 text-[#DEC4EF] mx-auto mb-3" />
                <h3 className="font-serif text-2xl text-[#2D1527] font-normal">
                  No matching outfits found
                </h3>
                <p className="text-xs sm:text-sm text-[#7A5370] max-w-md mx-auto mt-1 mb-6">
                  We couldn’t find any pieces with the current filters. Try resetting the occasion or category filters.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-5 py-2.5 rounded-full bg-[#2D1527] text-white text-xs font-medium hover:bg-[#441D3A] transition-colors"
                >
                  Reset All Filters
                </button>
              </div>
            )}
          </section>
        </div>
      </main>

      {/* About Us section at the very bottom, above the footer */}
      <AboutUs />

      {/* Footer with affiliate disclosure */}
      <Footer
        onScrollToTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
      />

      {/* Product Detail Popup Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={Boolean(selectedProduct)}
        onClose={() => setSelectedProduct(null)}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        isInMyStyle={selectedProduct ? myStyleIds.includes(selectedProduct.id) : false}
        onToggleWishlist={(p) => toggleWishlist(undefined, p)}
        onToggleMyStyle={(p) => toggleMyStyle(undefined, p)}
      />

      {/* Wishlist Drawer with All, Occasion tabs, and My Style tab */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveFromWishlist={removeFromWishlist}
        myStyleProducts={myStyleProducts}
        onRemoveFromMyStyle={removeFromMyStyle}
        savedLooks={savedLooks}
        onDeleteSavedLook={handleDeleteSavedLook}
        onSelectProduct={(p) => {
          setIsWishlistOpen(false);
          setSelectedProduct(p);
        }}
        onOpenQuiz={() => {
          setIsWishlistOpen(false);
          setIsQuizOpen(true);
        }}
      />

      {/* Build Your Style Quiz Modal */}
      <StyleQuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        products={PRODUCTS}
        onSaveLook={handleSaveLook}
        onOpenMyStyle={() => setIsWishlistOpen(true)}
      />
    </div>
  );
}
