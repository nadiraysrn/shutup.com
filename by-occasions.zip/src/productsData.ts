import { Product } from './types';

/* ==========================================================================
   PRODUCT CATALOG (EASY TO EDIT)
   --------------------------------------------------------------------------
   To edit or add products:
   1. Change 'name', 'occasion', 'category', 'budget', 'color', or 'image'.
   2. 'store': Must be either "Shopee" or "Amazon".
   3. 'buyUrl': Replace "PASTE-AFFILIATE-LINK-HERE" with your affiliate link.
   4. 'reviewUrl': Replace "PASTE-AFFILIATE-LINK-HERE" with your TikTok/IG URL.
   5. 'reviewEmbedUrl': (Optional) TikTok or Instagram embed video iframe URL.
      If empty or invalid, the app gracefully provides a button to open reviewUrl.
   ========================================================================== */

export const PRODUCTS: Product[] = [
  // --- PARTY ---
  {
    id: 'prod-party-1',
    name: 'Satin Pleated Tiered Abaya & Inner Dress Set',
    occasion: 'Party',
    category: 'set',
    budget: 'mid',
    color: 'Dusty Lilac',
    image: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Effortlessly luxurious silk-touch abaya with accordion pleats, matching slip dress and detachable belt.'
  },
  {
    id: 'prod-party-2',
    name: 'Champagne Shimmer Chiffon Silk Hijab',
    occasion: 'Party',
    category: 'hijab',
    budget: 'affordable',
    color: 'Champagne Shimmer',
    image: 'https://images.unsplash.com/photo-1590736969955-71cc94801759?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Lightweight chiffon woven with micro-fine gold lurex thread for an elegant, non-slip evening glow.'
  },
  {
    id: 'prod-party-3',
    name: 'Crystal Bow Satin Pointed Slingbacks',
    occasion: 'Party',
    category: 'shoes',
    budget: 'high fashion',
    color: 'Soft Plum',
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Statement kitten-heel pointed mules adorned with a double crystal bow brooch.'
  },
  {
    id: 'prod-party-4',
    name: 'Emerald Jacquard Modest Maxi Gown',
    occasion: 'Party',
    category: 'dress',
    budget: 'high fashion',
    color: 'Deep Plum & Emerald',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Opulent woven brocade with high mock neckline, balloon sleeves, and full A-line sweep.'
  },
  {
    id: 'prod-party-5',
    name: 'Pearl Embellished Minaudière Evening Clutch',
    occasion: 'Party',
    category: 'accessories',
    budget: 'affordable',
    color: 'Ivory Pearl',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Hard-shell structured clutch completely hand-set with ivory pearls and brass hardware.'
  },

  // --- BEACH ---
  {
    id: 'prod-beach-1',
    name: 'Breeze Pure Linen 2-Piece Resort Co-ord',
    occasion: 'Beach',
    category: 'set',
    budget: 'mid',
    color: 'Oatmeal Sand',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Airy 100% French linen long tunic and wide-leg trousers designed for breezy oceanside walks.'
  },
  {
    id: 'prod-beach-2',
    name: 'UV50+ Modest Swim Tunic & Wrap Skirt',
    occasion: 'Beach',
    category: 'dress',
    budget: 'mid',
    color: 'Sage Mist',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Quick-dry, chlorine-resistant modest swimwear set with attached cap, tunic, and leggings.'
  },
  {
    id: 'prod-beach-3',
    name: 'Crinkled Cotton Breathable Beach Hijab',
    occasion: 'Beach',
    category: 'hijab',
    budget: 'affordable',
    color: 'Vanilla Cream',
    image: 'https://images.unsplash.com/photo-1609357605129-26f69add5d6e?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'No-iron crinkle cotton scarf that stays in place even in windy seaside coastal air.'
  },
  {
    id: 'prod-beach-4',
    name: 'Handcrafted Raffia Beach Tote & Straw Visor',
    occasion: 'Beach',
    category: 'accessories',
    budget: 'affordable',
    color: 'Natural Tan',
    image: 'https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Spacious braided palm leaf tote featuring vegan leather handles and roomy sun-day storage.'
  },
  {
    id: 'prod-beach-5',
    name: 'Braided Strap Waterproof Cushioned Slides',
    occasion: 'Beach',
    category: 'shoes',
    budget: 'affordable',
    color: 'Bone White',
    image: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Water-friendly moulded footbed slide sandals with elegant braided double straps.'
  },

  // --- FORMAL ---
  {
    id: 'prod-formal-1',
    name: 'Sculpted Crepe Modest Evening Cape Gown',
    occasion: 'Formal',
    category: 'dress',
    budget: 'high fashion',
    color: 'Royal Plum',
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Stately crepe gown featuring an attached floor-length cascading capelet and modest boatneck.'
  },
  {
    id: 'prod-formal-2',
    name: 'Medina Silk Matte Luxury Formal Hijab',
    occasion: 'Formal',
    category: 'hijab',
    budget: 'mid',
    color: 'Deep Blackberry',
    image: 'https://images.unsplash.com/photo-1618244972963-dbee1a7edc95?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Heavyweight matte Medina silk with liquid-like drape, wrinkle resistance, and opaque coverage.'
  },
  {
    id: 'prod-formal-3',
    name: 'Double-Breasted Satin Lapel Tuxedo Blazer',
    occasion: 'Formal',
    category: 'top',
    budget: 'high fashion',
    color: 'Midnight Black',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Tailored feminine silhouette with satin peak lapels and covered buttons for formal galas.'
  },
  {
    id: 'prod-formal-4',
    name: 'Mother of Pearl Inlaid Minaudière Box',
    occasion: 'Formal',
    category: 'accessories',
    budget: 'high fashion',
    color: 'Iridescent Pearl',
    image: 'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Jeweled heirloom evening box bag hand-inlaid with natural shimmering mother of pearl mosaic.'
  },

  // --- CORPORATE ---
  {
    id: 'prod-corp-1',
    name: 'Tailored Wide-Leg Trousers & Longline Blazer Set',
    occasion: 'Corporate',
    category: 'set',
    budget: 'mid',
    color: 'Taupe Grey',
    image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'A modest power suit cut with modest ease: high-waisted fluid trousers paired with a hip-length blazer.'
  },
  {
    id: 'prod-corp-2',
    name: 'High-Neck Pleated Bow Silk Blouse',
    occasion: 'Corporate',
    category: 'top',
    budget: 'affordable',
    color: 'Soft Pearl Pink',
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Modest high neckline featuring a removable pussybow tie and gentle shoulder gathers.'
  },
  {
    id: 'prod-corp-3',
    name: 'Modal Bamboo Instant Wrap Hijab',
    occasion: 'Corporate',
    category: 'hijab',
    budget: 'affordable',
    color: 'Soft Charcoal',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Buttery-soft breathable modal bamboo blend with instant non-slip undercap structure for busy workdays.'
  },
  {
    id: 'prod-corp-4',
    name: 'Architectural Leather Laptop Work Tote',
    occasion: 'Corporate',
    category: 'accessories',
    budget: 'high fashion',
    color: 'Burgundy Plum',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Structured genuine leather tote with padded 15" laptop sleeve and subtle gold hardware.'
  },
  {
    id: 'prod-corp-5',
    name: 'Polished Horsebit Leather Loafer Mules',
    occasion: 'Corporate',
    category: 'shoes',
    budget: 'mid',
    color: 'Ebony Leather',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Classic boardroom slip-on mules with memory foam insoles and understated brushed metal horsebit.'
  },

  // --- CASUAL · STREET ---
  {
    id: 'prod-street-1',
    name: 'Oversized Raglan Sleeve Trench Duster Coat',
    occasion: 'Casual · Street',
    category: 'top',
    budget: 'mid',
    color: 'Warm Sand Khaki',
    image: 'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Floor-grazing modern street duster coat with dramatic storm flaps and deep welt pockets.'
  },
  {
    id: 'prod-street-2',
    name: 'Fluid Lyocell Wide-Leg Cargo Trousers',
    occasion: 'Casual · Street',
    category: 'bottom',
    budget: 'affordable',
    color: 'Olive Green',
    image: 'https://images.unsplash.com/photo-1509551388413-e18d0ac5d495?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Drapey, non-bulky cargo pants with subtle utility pockets and an elasticated comfortable waist.'
  },
  {
    id: 'prod-street-3',
    name: 'Everyday Premium Jersey Scarf',
    occasion: 'Casual · Street',
    category: 'hijab',
    budget: 'affordable',
    color: 'Mochaccino',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: '4-way stretch premium cotton jersey that drapes cleanly without needing pins or magnets.'
  },
  {
    id: 'prod-street-4',
    name: 'Retro Monochrome Chunky Platform Trainers',
    occasion: 'Casual · Street',
    category: 'shoes',
    budget: 'mid',
    color: 'Off-White & Slate',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Lightweight cushioned sole with vintage court sneaker silhouette, perfect for city walking.'
  },

  // --- CASUAL · WEEKEND ---
  {
    id: 'prod-weekend-1',
    name: 'Tiered Organic Cotton Smock Maxi Dress',
    occasion: 'Casual · Weekend',
    category: 'dress',
    budget: 'affordable',
    color: 'Soft Lavender Lilac',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Gathered smocked tiers in lightweight washed cotton with elasticated cuffs and deep hidden pockets.'
  },
  {
    id: 'prod-weekend-2',
    name: 'Knit Ribbed Longline Cardigan & Wide Pants Set',
    occasion: 'Casual · Weekend',
    category: 'set',
    budget: 'mid',
    color: 'Heathered Almond',
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Ultra-cozy weekend knitwear duo with duster length cardigan and breathable relaxed-cut culottes.'
  },
  {
    id: 'prod-weekend-3',
    name: 'Chiffon Georgette Light Square Hijab',
    occasion: 'Casual · Weekend',
    category: 'hijab',
    budget: 'affordable',
    color: 'Blush Cream',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Featherlight square scarf with rolled hem edges for casual coffee runs and weekend farmer markets.'
  },
  {
    id: 'prod-weekend-4',
    name: 'Quilted Nylon Slouchy Hobo Crossbody Bag',
    occasion: 'Casual · Weekend',
    category: 'accessories',
    budget: 'affordable',
    color: 'Cloud Lilac',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Ultra-lightweight cloud quilted bag that holds your everyday essentials without weighing you down.'
  },

  // --- FIRST DATE ---
  {
    id: 'prod-date-1',
    name: 'Embroidered Meadow Tiered Chiffon Maxi',
    occasion: 'First date',
    category: 'dress',
    budget: 'mid',
    color: 'Blush Rose & Plum',
    image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Romantic vintage-inspired silhouette with subtle botanical embroidery, fully lined with modest coverage.'
  },
  {
    id: 'prod-date-2',
    name: 'Silk Crepe Pearlescent Hijab',
    occasion: 'First date',
    category: 'hijab',
    budget: 'affordable',
    color: 'Dusty Mauve',
    image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Delicate silk crepe with a subtle pearlescent sheen that frames the face with romantic radiance.'
  },
  {
    id: 'prod-date-3',
    name: 'Sculpted Minimalist Kitten Heel Slingbacks',
    occasion: 'First date',
    category: 'shoes',
    budget: 'mid',
    color: 'Nude Almond',
    image: 'https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?q=80&w=900&auto=format&fit=crop',
    store: 'Amazon',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Walkable 45mm architectural kitten heel with cushioned insole for dinner and quiet strolls.'
  },
  {
    id: 'prod-date-4',
    name: 'Fluffy Cashmere-Blend Wrap Cardigan',
    occasion: 'First date',
    category: 'top',
    budget: 'high fashion',
    color: 'Soft Petal Pink',
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Feather-soft fine gauge knit with waist tie closure, layering gracefully over dresses.'
  },
  {
    id: 'prod-date-5',
    name: 'Gilded Baroque Pearl Drop Earrings (or Scarf Brooch)',
    occasion: 'First date',
    category: 'accessories',
    budget: 'affordable',
    color: 'Warm Gold',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=900&auto=format&fit=crop',
    store: 'Shopee',
    buyUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewUrl: 'PASTE-AFFILIATE-LINK-HERE',
    reviewEmbedUrl: '',
    description: 'Organic freshwater pearl suspended from a 18k gold plated hammered leaf clip/brooch.'
  }
];

export const OCCASIONS_LIST: Array<Product['occasion']> = [
  'Party',
  'Beach',
  'Formal',
  'Corporate',
  'Casual · Street',
  'Casual · Weekend',
  'First date'
];
